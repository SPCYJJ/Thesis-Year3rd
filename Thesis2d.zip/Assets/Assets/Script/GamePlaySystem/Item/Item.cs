﻿using UnityEngine;

public class Item : MonoBehaviour
{
    public string itemID;
    public string itemName;
    public Sprite icon;

    [Header("Highlight")]
    public SpriteRenderer spriteRenderer;
    public Color normalColor = Color.white;
    public Color highlightColor = Color.yellow;

    public bool playerInside { get; private set; }
    private bool canPickUp;

    void Start()
    {
        spriteRenderer.color = normalColor;
    }

    void Awake()
    {
        Debug.Log("Item Spawned: " + gameObject.name);
    }

    void OnDestroy()
    {
        Debug.Log("Item Destroyed: " + gameObject.name);
    }


    void Update()
    {
        if (playerInside && canPickUp && Input.GetKeyDown(KeyCode.E))
        {
            PickUp();
        }
    }
    void PickUp()
    {
        Player player = FindObjectOfType<Player>();
        player.AddItem(this);
        gameObject.SetActive(false);
    }

    public void Highlight(bool on)
    {
        canPickUp = on;
        spriteRenderer.color = on ? highlightColor : normalColor;
    }

    public void SetPlayerInside(bool inside)
    {
        playerInside = inside;
    }
}
