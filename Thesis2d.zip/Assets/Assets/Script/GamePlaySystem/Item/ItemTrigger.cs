﻿using UnityEngine;

public class ItemTrigger : MonoBehaviour
{
    private Item item;

    void Awake()
    {
        item = GetComponentInParent<Item>();

        if (item == null)
            Debug.LogError("ItemTrigger has no parent Item!", this);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        item.SetPlayerInside(true);
        item.Highlight(true);

        PressEUI.Instance?.Show(true);
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        item.SetPlayerInside(false);
        item.Highlight(false);

        PressEUI.Instance?.Show(false);
    }
}
