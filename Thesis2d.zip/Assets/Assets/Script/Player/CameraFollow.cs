﻿using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float smoothSpeed = 5f;

    [Header("Camera Bounds")]
    public Vector2 minBounds;
    public Vector2 maxBounds;

    private float camHalfHeight;
    private float camHalfWidth;

    void Start()
    {
        Camera cam = Camera.main;
        camHalfHeight = cam.orthographicSize;
        camHalfWidth = camHalfHeight * cam.aspect;
    }

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 desiredPos = new Vector3(
            target.position.x,
            target.position.y,
            transform.position.z
        );

        // Clamp ไม่ให้กล้องออกนอกฉาก
        float clampedX = Mathf.Clamp(
            desiredPos.x,
            minBounds.x + camHalfWidth,
            maxBounds.x - camHalfWidth
        );

        float clampedY = Mathf.Clamp(
            desiredPos.y,
            minBounds.y + camHalfHeight,
            maxBounds.y - camHalfHeight
        );

        Vector3 finalPos = new Vector3(clampedX, clampedY, desiredPos.z);

        transform.position = Vector3.Lerp(
            transform.position,
            finalPos,
            smoothSpeed * Time.deltaTime
        );
    }
}
