using UnityEngine;

public class PressEUI : MonoBehaviour
{
    public static PressEUI Instance;
    public GameObject pressEText;

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        pressEText.SetActive(false);
    }

    public void Show(bool show)
    {
        pressEText.SetActive(show);
    }
}
