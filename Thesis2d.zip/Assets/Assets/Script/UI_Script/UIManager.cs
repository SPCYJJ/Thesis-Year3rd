﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    /* ======================
     * Inventory UI
     * ====================== */
    [Header("Inventory UI")]
    public GameObject inventoryPanel;
    public List<Image> slots = new List<Image>();

    /* ======================
     * Stamina UI
     * ====================== */
    [Header("Stamina UI")]
    public Image staminaFill;
    public GameObject staminaRoot;
    public Player player;
    public Color staminaFullColor = Color.white;
    public Color staminaLowColor = Color.black;

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        staminaRoot.SetActive(false);

        inventoryPanel.SetActive(false);
    }

    void Update()
    {
        HandleInventoryInput();
        UpdateStaminaUI();
    }

    /* ======================
     * Inventory
     * ====================== */
    void HandleInventoryInput()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            ToggleInventory();
        }
    }

    void ToggleInventory()
    {
        bool isOpen = !inventoryPanel.activeSelf;
        inventoryPanel.SetActive(isOpen);
        Time.timeScale = isOpen ? 0f : 1f;
    }

    public void Refresh(List<Item> items)
    {
        // ล้างช่องก่อน
        foreach (var slot in slots)
        {
            slot.sprite = null;
            slot.color = new Color(1, 1, 1, 0);
        }

        // ใส่ไอเทมลงช่อง
        for (int i = 0; i < items.Count && i < slots.Count; i++)
        {
            slots[i].sprite = items[i].icon;
            slots[i].color = Color.white;
        }
    }

    /* ======================
     * Stamina
     * ====================== */
    void UpdateStaminaUI()
    {
        if (player == null || staminaFill == null || staminaRoot == null) return;

        float percent = player.currentStamina / player.maxStamina;

        // อัปเดตค่า
        staminaFill.fillAmount = percent;

        // แสดงหลอดเมื่อวิ่ง
        if (player.isRunning)
        {
            staminaRoot.SetActive(true);
        }

        // ถ้า stamina เต็ม และไม่ได้วิ่ง → ซ่อน
        if (!player.isRunning && percent >= 0.99f)
        {
            staminaRoot.SetActive(false);
            player.staminaJustUsed = false;
        }
    }

}
